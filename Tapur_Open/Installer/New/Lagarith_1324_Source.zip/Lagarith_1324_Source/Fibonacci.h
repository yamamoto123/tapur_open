
#pragma once

int FibonacciDecode2(const unsigned char * in, unsigned int * out);
unsigned int FibonacciEncode2(unsigned int * in, unsigned char * out);
inline unsigned int FibonacciDecode(const unsigned char * in, int * out, int length);

