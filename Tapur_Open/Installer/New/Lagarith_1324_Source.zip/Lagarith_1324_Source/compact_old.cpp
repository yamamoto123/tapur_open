#ifndef _COMPACT_OLD_CPP
#define _COMPACT_OLD_CPP

// This file is mantained only for compatablity with earlier versions of lagarith

#include "compact.h"
#include "fibonacci.h"
#include "rle.h"
#include "zeroRLE.h"

// read the byte frequency header 

unsigned int CompressClass::Old_Readprob(const unsigned char * in){
	int length=0;
	prob_ranges[0]=0;

	unsigned char header[257];
	prob_ranges[0]=0;

	int skip;
	if ( in[0] ){
		int size = *(int*)(in+1);
		skip = rle::deRLE(in+5,header,size,in[0]);
		skip += 5;
		FibonacciDecode(header,(int *)&prob_ranges[1],256);
	} else {
		skip= FibonacciDecode(in+1,(int*)&prob_ranges[1],256)+1;
	}

	for ( int a=1; a<257; a++){
		length+=prob_ranges[a];
	}

	int temp = 1;
	while ( temp < length )
		temp*=2;
	
	double factor = temp/(float)length;

	for ( int a = 1; a < 257; a++ ){
		prob_ranges[a]= (unsigned int)(prob_ranges[a]*factor);
	}
	int newlen=0;
	for ( int a = 1; a < 257; a++ ){
		newlen+=prob_ranges[a];
	}

	newlen= temp-newlen;
	if ( newlen < 0 ){
		prob_ranges[1]+=newlen;
		newlen=0;
	}
	
	int a =0;
	unsigned char b=0;
	while ( newlen  ){
		prob_ranges[b]++;
		newlen--;
		a++;
		if ( a%2 )
			b= -((a+1)/2);
		else 
			b=a/2;
		if ( a == 256 ){
			a=0; 
			b=0;
		}
	}
	scale = temp;
	temp=0;
	for ( a =1; a < 257; a++ ){
		temp+=prob_ranges[a];
	}

	for ( a =0; scale; a++)
		scale/=2;
	scale =a-1;
	for ( a = 1; a < 257; a++ ){
		prob_ranges[a]+=prob_ranges[a-1];
	}
	return skip;
}

void CompressClass::Old_Uncompact(const unsigned char * in, unsigned char * out, unsigned int length){
	
	if ( in[0] ){
		int size = *(int*)(in+1);
		int skip = Old_Readprob((in+5));

		Decode_And_DeRLE(in+5+skip,out,length,in[0]);
		return;
	} else {
		int skip = Old_Readprob((in+1));
		Decode_And_DeRLE(in+skip+1,out,length,0);
		return;
	}
}

#endif