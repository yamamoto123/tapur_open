
#pragma once
bool DetectFlags();