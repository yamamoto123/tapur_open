
//This file contains functions that perform and undo median predition that are used by both x86 and x64
#include "prediction.h"
#include <mmintrin.h>
#include <emmintrin.h>
#include <xmmintrin.h>
#include <stdlib.h>
#include <memory.h>
#include <assert.h>

#define align_round(x,y) ((((unsigned int)(x))+(y-1))&(~(y-1)))

// this effectively performs a bubble sort to select the median:
// min(max(min(x,y),z),max(x,y))
inline int median(int x,int y,int z ) {
	int delta = x-y;
	delta &= delta>>31;
	int i = y+delta;	//i=min(x,y);
	int j = x-delta;	//j=max(x,y);
	delta = i-z;
	delta &= delta>>31;
	i = i-delta;	//i=max(i,z);
	delta = i-j;
	delta &= delta>>31;
	return  j+delta;	//j=min(i,j);
}

void SSE2_Block_Predict( const unsigned char * __restrict source, unsigned char * __restrict dest, const unsigned int width, const unsigned int length, const bool rgbmode){

	unsigned int align_shift = (16 - ((unsigned int)source&15))&15;

	// predict the bottom row
	unsigned int a;
	__m128i t0 = _mm_setzero_si128();
	if ( align_shift ){
		dest[0]=source[0];
		for ( a=1;a<align_shift;a++){
			dest[a] = source[a]-source[a-1];
		}
		t0 = _mm_insert_epi16(t0,source[align_shift-1],0);
	}
	for ( a=align_shift;a<width;a+=16){
		__m128i x = *(__m128i*)&source[a];
		t0 = _mm_or_si128(t0,_mm_slli_si128(x,1));
		*(__m128i*)&dest[a]=_mm_sub_epi8(x,t0);
		t0 = _mm_srli_si128(x,15);
	}

	if ( width==length )
		return;

	__m128i z = _mm_setzero_si128();
	__m128i x = _mm_setzero_si128();

	if ( rgbmode ){
		x = _mm_insert_epi16(x,source[0],0);
	} else {
		x = _mm_insert_epi16(x,source[width-1],0);
		z = _mm_insert_epi16(z,source[0],0);
	}

	const __m128i zero = _mm_setzero_si128();
	a = width;
	{
		// this block makes sure that source[a] is aligned to 16
		__m128i srcs = _mm_loadu_si128((__m128i *)&source[a]);
		__m128i y = _mm_loadu_si128((__m128i *)&source[a-width]);

		x = _mm_or_si128(x,_mm_slli_si128(srcs,1));
		z = _mm_or_si128(z,_mm_slli_si128(y,1));

		__m128i tx = _mm_unpackhi_epi8(x,zero);
		__m128i ty = _mm_unpackhi_epi8(y,zero);
		__m128i tz = _mm_unpackhi_epi8(z,zero);

		tz = _mm_add_epi16(_mm_sub_epi16(tx,tz),ty);

		tx = _mm_unpacklo_epi8(x,zero);
		ty = _mm_unpacklo_epi8(y,zero);
		z = _mm_unpacklo_epi8(z,zero);
		z = _mm_add_epi16(_mm_sub_epi16(tx,z),ty);
		z = _mm_packus_epi16(z,tz);

		__m128i i = _mm_min_epu8(x,y);
		x = _mm_max_epu8(x,y);
		i = _mm_max_epu8(i,z);
		x = _mm_min_epu8(x,i);

		srcs = _mm_sub_epi8(srcs,x);
		_mm_storeu_si128((__m128i*)&dest[a],srcs);
	}
	
	if ( align_shift ){
		a = align_round(a,16);
		a += align_shift;
		if ( a > width+16 ){
			a -= 16;
		}
	} else {
		a+=16;
		a&=(~15);
	}
	// source[a] is now aligned
	z = _mm_setzero_si128();
	x = _mm_setzero_si128();
	x = _mm_insert_epi16(x,source[a-1],0);
	z = _mm_insert_epi16(z,source[a-width-1],0);


	const unsigned int end = (length>=15)?length-15:0;

	// if width is a multiple of 16, use faster aligned reads
	// inside the prediction loop
	if ( width%16 == 0 ){
		for ( ;a<end;a+=16){

			__m128i srcs = *(__m128i *)&source[a];
			__m128i y = *(__m128i *)&source[a-width];

			x = _mm_or_si128(x,_mm_slli_si128(srcs,1));
			z = _mm_or_si128(z,_mm_slli_si128(y,1));

			__m128i tx = _mm_unpackhi_epi8(x,zero);
			__m128i ty = _mm_unpackhi_epi8(y,zero);
			__m128i tz = _mm_unpackhi_epi8(z,zero);

			tz = _mm_add_epi16(_mm_sub_epi16(tx,tz),ty);

			tx = _mm_unpacklo_epi8(x,zero);
			ty = _mm_unpacklo_epi8(y,zero);
			z = _mm_unpacklo_epi8(z,zero);
			z = _mm_add_epi16(_mm_sub_epi16(tx,z),ty);
			z = _mm_packus_epi16(z,tz);

			__m128i i = _mm_min_epu8(x,y);
			x = _mm_max_epu8(x,y);
			i = _mm_max_epu8(i,z);
			x = _mm_min_epu8(x,i);

			i = _mm_srli_si128(srcs,15);

			srcs = _mm_sub_epi8(srcs,x);

			z = _mm_srli_si128(y,15);
			x = i;

			*(__m128i*)&dest[a] = srcs;
		}
	} else {
		// main prediction loop, source[a-width] is unaligned
		for ( ;a<end;a+=16){

			__m128i srcs = *(__m128i *)&source[a];
			__m128i y = _mm_loadu_si128((__m128i *)&source[a-width]);

			x = _mm_or_si128(x,_mm_slli_si128(srcs,1));
			z = _mm_or_si128(z,_mm_slli_si128(y,1));

			__m128i tx = _mm_unpackhi_epi8(x,zero);
			__m128i ty = _mm_unpackhi_epi8(y,zero);
			__m128i tz = _mm_unpackhi_epi8(z,zero);

			tz = _mm_add_epi16(_mm_sub_epi16(tx,tz),ty);

			tx = _mm_unpacklo_epi8(x,zero);
			ty = _mm_unpacklo_epi8(y,zero);
			z = _mm_unpacklo_epi8(z,zero);
			z = _mm_add_epi16(_mm_sub_epi16(tx,z),ty);
			z = _mm_packus_epi16(z,tz);

			__m128i i = _mm_min_epu8(x,y);
			x = _mm_max_epu8(x,y);
			i = _mm_max_epu8(i,z);
			x = _mm_min_epu8(x,i);

			i = _mm_srli_si128(srcs,15);

			srcs = _mm_sub_epi8(srcs,x);

			z = _mm_srli_si128(y,15);
			x = i;

			*(__m128i*)&dest[a] = srcs;
		}
	}
	for ( ; a<length; a++ ){
		int x = source[a-1];
		int y = source[a-width];
		int z = x+y-source[a-width-1];
		dest[a] = source[a]-median(x,y,z);
	}
}

void SSE2_Block_Predict_YUV16( const unsigned char * __restrict source, unsigned char * __restrict dest, const unsigned int width, const unsigned int length, const bool is_y){

	unsigned int align_shift = (16 - ((int)source&15))&15;

	// predict the bottom row
	unsigned int a;
	__m128i t0 = _mm_setzero_si128();
	if ( align_shift ){
		dest[0]=source[0];
		for ( a=1;a<align_shift;a++){
			dest[a] = source[a]-source[a-1];
		}
		t0 = _mm_insert_epi16(t0,source[align_shift-1],0);
	}
	for ( a=align_shift;a<width;a+=16){
		__m128i x = *(__m128i*)&source[a];
		t0 = _mm_or_si128(t0,_mm_slli_si128(x,1));
		*(__m128i*)&dest[a]=_mm_sub_epi8(x,t0);
		t0 = _mm_srli_si128(x,15);
	}
	if ( width==length )
		return;

	__m128i z;
	__m128i x;

	const __m128i zero = _mm_setzero_si128();
	a = width;
	{
		// this block makes sure that source[a] is aligned to 16
		__m128i srcs = _mm_loadu_si128((__m128i *)&source[a]);
		__m128i y = _mm_loadu_si128((__m128i *)&source[a-width]);

		x = _mm_slli_si128(srcs,1);
		z = _mm_slli_si128(y,1);
		z = _mm_add_epi8(_mm_sub_epi8(x,z),y);

		__m128i i = _mm_min_epu8(x,y);
		x = _mm_max_epu8(x,y);
		i = _mm_max_epu8(i,z);
		x = _mm_min_epu8(x,i);

		srcs = _mm_sub_epi8(srcs,x);
		_mm_storeu_si128((__m128i*)&dest[a],srcs);
	}

	if ( align_shift ){
		a = align_round(a,16);
		a += align_shift;
		if ( a > width+16 ){
			a -= 16;
		}
	} else {
		a+=16;
		a&=(~15);
	}
	// source[a] is now aligned
	z = _mm_setzero_si128();
	x = _mm_setzero_si128();
	x = _mm_insert_epi16(x,source[a-1],0);
	z = _mm_insert_epi16(z,source[a-width-1],0);


	const unsigned int end = (length>=15)?length-15:0;
	// if width is a multiple of 16, use faster aligned reads
	// inside the prediction loop
	if ( width%16 == 0 ){
		for ( ;a<end;a+=16){

			__m128i srcs = *(__m128i *)&source[a];
			__m128i y = *(__m128i *)&source[a-width];

			x = _mm_or_si128(x,_mm_slli_si128(srcs,1));
			z = _mm_or_si128(z,_mm_slli_si128(y,1));
			z = _mm_add_epi8(_mm_sub_epi8(x,z),y);

			__m128i i = _mm_min_epu8(x,y);
			x = _mm_max_epu8(x,y);
			i = _mm_max_epu8(i,z);
			x = _mm_min_epu8(x,i);

			i = _mm_srli_si128(srcs,15);

			srcs = _mm_sub_epi8(srcs,x);

			z = _mm_srli_si128(y,15);
			x = i;

			*(__m128i*)&dest[a] = srcs;
		}
	} else {
		// main prediction loop, source[a-width] is unaligned
		for ( ;a<end;a+=16){

			__m128i srcs = *(__m128i *)&source[a];
			__m128i y = _mm_loadu_si128((__m128i *)&source[a-width]);

			x = _mm_or_si128(x,_mm_slli_si128(srcs,1));
			z = _mm_or_si128(z,_mm_slli_si128(y,1));
			z = _mm_add_epi8(_mm_sub_epi8(x,z),y);

			__m128i i = _mm_min_epu8(x,y);
			x = _mm_max_epu8(x,y);
			i = _mm_max_epu8(i,z);
			x = _mm_min_epu8(x,i);

			i = _mm_srli_si128(srcs,15);

			srcs = _mm_sub_epi8(srcs,x);

			z = _mm_srli_si128(y,15);
			x = i;

			*(__m128i*)&dest[a] = srcs;
		}
	}
	for ( ; a<length; a++ ){
		int x = source[a-1];
		int y = source[a-width];
		int z = (x+y-source[a-width-1])&255;
		dest[a] = source[a]-median(x,y,z);
	}

	if ( is_y ){
		dest[1]=source[1];
	}
	dest[width] = source[width]-source[width-1];
	dest[width+1] = source[width+1]-source[width];

	if ( is_y ){
		dest[width+2] = source[width+2]-source[width+1];
		dest[width+3] = source[width+3]-source[width+2];
	}
}
