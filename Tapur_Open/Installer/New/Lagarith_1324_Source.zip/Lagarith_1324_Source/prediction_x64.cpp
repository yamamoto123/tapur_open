
//This file contains functions that perform and undo median predition for x64
#ifdef X64_BUILD
#include "prediction.h"
#include <mmintrin.h>
#include <emmintrin.h>
#include <xmmintrin.h>
#include <stdlib.h>
#include <memory.h>
#include <assert.h>
#include <stdio.h>
#include <windows.h>

#define align_round(x,y) ((((unsigned int)(x))+(y-1))&(~(y-1)))
#define sub_us(x,y) (((x)>(y))?((x)-(y)):0)

// this effectively performs a bubble sort to select the median:
// min(max(min(x,y),z),max(x,y))
inline int median(int x,int y,int z ) {
	int delta = x-y;
	delta &= delta>>31;
	int i = y+delta;	//i=min(x,y);
	int j = x-delta;	//j=max(x,y);
	delta = i-z;
	delta &= delta>>31;
	i = i-delta;	//i=max(i,z);
	delta = i-j;
	delta &= delta>>31;
	return  j+delta;	//j=min(i,j);
}

void Decorrilate_And_Split_RGB24(const unsigned char * __restrict in, unsigned char * __restrict rdst, unsigned char * __restrict gdst, unsigned char * __restrict bdst, const unsigned int width, const unsigned int height){
	
	const unsigned int stride = align_round(width*3,4);
	const unsigned int vsteps = (width&3)?height:1;
	const unsigned int wsteps = (width&3)?(width&(~3)):width*height;
	__m128i mask = _mm_set_epi32(255,255,255,255);
	for ( unsigned int y=0; y<vsteps; y++){
		unsigned int x;
		for ( x=0; x<wsteps; x+=4){
			__m128i x0 = _mm_loadl_epi64((__m128i*)&in[y*stride+x*3+0]);
			__m128i x3 = _mm_cvtsi32_si128(*(int*)&in[y*stride+x*3+8]);
			x3 = _mm_slli_si128(x3,8);
			x0 = _mm_or_si128(x0,x3);
			
			__m128i x1 = _mm_srli_si128(x0,3);
			__m128i x2 = _mm_srli_si128(x0,6);
			x3 = _mm_srli_si128(x3,9);

			x0 = _mm_unpacklo_epi32(x0,x1);
			x2 = _mm_unpacklo_epi32(x2,x3);
			x0 = _mm_unpacklo_epi64(x0,x2);

			__m128i r = _mm_srli_si128(x0,2);
			__m128i g = _mm_srli_si128(x0,1);
			__m128i b = x0;
			r = _mm_and_si128(r,mask);
			g = _mm_and_si128(g,mask);
			b = _mm_and_si128(b,mask);

			r = _mm_packs_epi32(r,r);
			g = _mm_packs_epi32(g,g);
			b = _mm_packs_epi32(b,b);

			r = _mm_packus_epi16(r,r);
			g = _mm_packus_epi16(g,g);
			b = _mm_packus_epi16(b,b);

			r = _mm_sub_epi8(r,g);
			b = _mm_sub_epi8(b,g);

			*(int*)&bdst[y*width+x] = _mm_cvtsi128_si32(b);
			*(int*)&gdst[y*width+x] = _mm_cvtsi128_si32(g);
			*(int*)&rdst[y*width+x] = _mm_cvtsi128_si32(r);
		}
		for ( ;x < width; x++ ){
			bdst[y*width+x] = in[y*stride+x*3+0]-in[y*stride+x*3+1];
			gdst[y*width+x] = in[y*stride+x*3+1];
			rdst[y*width+x] = in[y*stride+x*3+2]-in[y*stride+x*3+1];
		}
	}
}

void Decorrilate_And_Split_RGB32(const unsigned char * __restrict in, unsigned char * __restrict rdst, unsigned char * __restrict gdst, unsigned char * __restrict bdst, const unsigned int width, const unsigned int height){

	const __m128i mask = _mm_set_epi32(255,255,255,255);
	unsigned int a=0;
	const unsigned int end = (width*height)&(~7);
	for ( a=0; a<end; a+=8){
		
		__m128i x0 = *(__m128i*)&in[a*4+0];
		__m128i x2 = *(__m128i*)&in[a*4+16];

		__m128i r = _mm_srli_si128(x0,2);
		__m128i g = _mm_srli_si128(x0,1);
		__m128i b = x0;
		r = _mm_and_si128(r,mask);
		g = _mm_and_si128(g,mask);
		b = _mm_and_si128(b,mask);

		x0 = _mm_srli_si128(x2,2);
		__m128i x1 = _mm_srli_si128(x2,1);
		//x2 = x2

		x0 = _mm_and_si128(x0,mask);
		x1 = _mm_and_si128(x1,mask);
		x2 = _mm_and_si128(x2,mask);

		r = _mm_packs_epi32(r,x0);
		g = _mm_packs_epi32(g,x1);
		b = _mm_packs_epi32(b,x2);

		r = _mm_packus_epi16(r,r);
		g = _mm_packus_epi16(g,g);
		b = _mm_packus_epi16(b,b);

		r = _mm_sub_epi8(r,g);
		b = _mm_sub_epi8(b,g);

		_mm_storel_epi64((__m128i*)&bdst[a],b);
		_mm_storel_epi64((__m128i*)&gdst[a],g);
		_mm_storel_epi64((__m128i*)&rdst[a],r);

	}
	for ( ;a < width*height; a++ ){
		bdst[a] = in[a*4+0]-in[a*4+1];
		gdst[a] = in[a*4+1];
		rdst[a] = in[a*4+2]-in[a*4+1];
	}
}

void Decorrilate_And_Split_RGBA(const unsigned char * __restrict in, unsigned char * __restrict rdst, unsigned char * __restrict gdst, unsigned char * __restrict bdst, unsigned char * __restrict adst, const unsigned int width, const unsigned int height){
	const __m128i mask = _mm_set_epi32(255,255,255,255);
	unsigned int a=0;
	const unsigned int end = (width*height)&(~7);
	for ( a=0; a<end; a+=8){

		__m128i x0 = *(__m128i*)&in[a*4+0];
		__m128i x2 = *(__m128i*)&in[a*4+16];

		__m128i alpha = _mm_srli_epi32(x0,24);
		__m128i r = _mm_srli_si128(x0,2);
		__m128i g = _mm_srli_si128(x0,1);
		__m128i b = x0;
		r = _mm_and_si128(r,mask);
		g = _mm_and_si128(g,mask);
		b = _mm_and_si128(b,mask);

		x0 = _mm_srli_si128(x2,2);
		__m128i x3 = _mm_srli_epi32(x2,24);
		__m128i x1 = _mm_srli_si128(x2,1);
		//x2 = x2

		x0 = _mm_and_si128(x0,mask);
		x1 = _mm_and_si128(x1,mask);
		x2 = _mm_and_si128(x2,mask);

		r = _mm_packs_epi32(r,x0);
		g = _mm_packs_epi32(g,x1);
		b = _mm_packs_epi32(b,x2);
		alpha = _mm_packs_epi32(alpha,x3);

		r = _mm_packus_epi16(r,r);
		g = _mm_packus_epi16(g,g);
		b = _mm_packus_epi16(b,b);
		alpha = _mm_packus_epi16(alpha,alpha);

		r = _mm_sub_epi8(r,g);
		b = _mm_sub_epi8(b,g);

		_mm_storel_epi64((__m128i*)&bdst[a],b);
		_mm_storel_epi64((__m128i*)&gdst[a],g);
		_mm_storel_epi64((__m128i*)&rdst[a],r);
		_mm_storel_epi64((__m128i*)&adst[a],alpha);

	}
	for ( ;a < width*height; a++ ){
		bdst[a] = in[a*4+0]-in[a*4+1];
		gdst[a] = in[a*4+1];
		rdst[a] = in[a*4+2]-in[a*4+1];
		adst[a] = in[a*4+3];
	}
}

void Split_YUY2(const unsigned char * __restrict src, unsigned char * __restrict ydst, unsigned char * __restrict udst, unsigned char * __restrict vdst, const unsigned int width, const unsigned int height){
	const __m128i ymask = _mm_set_epi32(0x00FF00FF,0x00FF00FF,0x00FF00FF,0x00FF00FF);
	//const __m128i cmask = _mm_set_epi32(0x000000FF,0x000000FF,0x000000FF,0x000000FF);

	unsigned int a;
	const unsigned int end = (width*height)&(~15);
	for ( a=0;a<end;a+=16){
		__m128i y0 = *(__m128i*)&src[a*2+0];
		__m128i y1 = *(__m128i*)&src[a*2+16];

		__m128i u0 = _mm_srli_epi32(_mm_slli_epi32(y0,16),24);
		__m128i v0 = _mm_srli_epi32(y0,24);
		y0 = _mm_and_si128(y0,ymask);

		__m128i u1 = _mm_srli_epi32(_mm_slli_epi32(y1,16),24);
		__m128i v1 = _mm_srli_epi32(y1,24);
		y1 = _mm_and_si128(y1,ymask);

		y0 = _mm_packus_epi16(y0,y1);
		v0 = _mm_packus_epi16(v0,v1);
		u0 = _mm_packus_epi16(u0,u1);
		v0 = _mm_packus_epi16(v0,v0);
		u0 = _mm_packus_epi16(u0,u0);

		*(__m128i*)&ydst[a] = y0;
		_mm_storel_epi64((__m128i*)&vdst[a/2],v0);
		_mm_storel_epi64((__m128i*)&udst[a/2],u0);
	}

	for ( ;a<height*width;a+=2){
		ydst[a+0] = src[a*2+0];
		vdst[a/2] = src[a*2+1];
		ydst[a+1] = src[a*2+2];
		udst[a/2] = src[a*2+3];
	}
}

void Split_UYVY(const unsigned char * __restrict src, unsigned char * __restrict ydst, unsigned char * __restrict udst, unsigned char * __restrict vdst, const unsigned int width, const unsigned int height){
	const __m128i ymask = _mm_set_epi32(0x00FF00FF,0x00FF00FF,0x00FF00FF,0x00FF00FF);
	const __m128i cmask = _mm_set_epi32(0x000000FF,0x000000FF,0x000000FF,0x000000FF);

	unsigned int a;
	const unsigned int end = (width*height)&(~15);
	for ( a=0;a<end;a+=16){
		__m128i u0 = *(__m128i*)&src[a*2+0];
		__m128i u1 = *(__m128i*)&src[a*2+16];

		__m128i y0 = _mm_srli_epi16(u0,8);
		__m128i v0 = _mm_and_si128(_mm_srli_si128(u0,2),cmask);
		u0 = _mm_and_si128(u0,cmask);

		__m128i y1 = _mm_srli_epi16(u1,8);
		__m128i v1 = _mm_and_si128(_mm_srli_si128(u1,2),cmask);
		u1 = _mm_and_si128(u1,cmask);

		y0 = _mm_packus_epi16(y0,y1);
		v0 = _mm_packus_epi16(v0,v1);
		u0 = _mm_packus_epi16(u0,u1);
		v0 = _mm_packus_epi16(v0,v0);
		u0 = _mm_packus_epi16(u0,u0);

		*(__m128i*)&ydst[a] = y0;
		_mm_storel_epi64((__m128i*)&vdst[a/2],v0);
		_mm_storel_epi64((__m128i*)&udst[a/2],u0);
	}

	for ( ;a<height*width;a+=2){
		vdst[a/2] = src[a*2+0];
		ydst[a+0] = src[a*2+1];
		udst[a/2] = src[a*2+2];
		ydst[a+1] = src[a*2+3];
	}
}

void Block_Predict( const unsigned char * __restrict source, unsigned char * __restrict dest, const unsigned int width, const unsigned int length, const bool rgbmode){
	SSE2_Block_Predict(source,dest,width,length,rgbmode);
}

void Block_Predict_YUV16( const unsigned char * __restrict source, unsigned char * __restrict dest, const unsigned int width, const unsigned int length, const bool is_y){
	SSE2_Block_Predict_YUV16(source,dest,width,length,is_y);
}

void Double_Resolution(const unsigned char * src, unsigned char * dst, unsigned char * buffer, unsigned int width, unsigned int height ){
	const unsigned char * source;
	unsigned char * dest;

	const unsigned int mod = 32;

	unsigned int stride = align_round(width,mod);

	if ( stride != width){
		unsigned int y;
		for ( y=0;y<height;y++){
			memcpy(dst+y*stride,src+y*width,width);
		}
		const unsigned char i = dst[y*stride+width-1];
		for ( unsigned int x=width;x<stride;x++){
			dst[y*stride+x]=i;
		}
		source = dst;
		dest = buffer;

	} else {
		source = src;
		dest = dst;
	}
	
	unsigned int y;
	for ( y=0;y<height;y++){
		__m128i p = *(__m128i *)(source+y*stride);
		p = _mm_slli_si128(p,15);
		p = _mm_srli_si128(p,15);
		for ( unsigned int x=0;x<stride;x+=16){
			__m128i a = *(__m128i *)(source+x+y*stride);
			__m128i b = _mm_slli_si128(a,1);

			b = _mm_or_si128(b,p);
			p = _mm_srli_si128(a,15);
			
			b = _mm_avg_epu8(a,b);

			*(__m128i*)(dest+x*2+y*stride*4) =  _mm_unpacklo_epi8(b,a);
			*(__m128i*)(dest+x*2+y*stride*4+16)=_mm_unpackhi_epi8(b,a);
		}
	}
	height*=2;
	stride*=2;
	width*=2;
	for ( y=0;y<height-2;y+=2){
		for ( unsigned int x=0;x<stride;x+=32){
			__m128i a = *(__m128i *)(dest+x+y*stride);
			__m128i b = *(__m128i *)(dest+x+y*stride+stride*2);

			__m128i c = *(__m128i *)(dest+x+y*stride+16);
			__m128i d = *(__m128i *)(dest+x+y*stride+stride*2+16);

			a=_mm_avg_epu8(a,b);
			c=_mm_avg_epu8(c,d);
			*(__m128i*)(dest+x+y*stride+stride)=a;
			*(__m128i*)(dest+x+y*stride+stride+16)=c;
		}
	}

	memcpy(dest+stride*(height-1),dest+stride*(height-2),stride);

	if ( stride != width ){
		for ( unsigned int y=0;y<height;y++){
			memcpy(dst+y*width,dest+y*stride,width);
		}
	}
}

void Interleave_And_Restore_YUY2( unsigned char * __restrict output, unsigned char * __restrict ysrc, const unsigned char * __restrict usrc, const unsigned char * __restrict vsrc, const unsigned int width, const unsigned int height){

	output[0]=ysrc[0];
	output[1]=usrc[0];
	output[2]=ysrc[1];
	output[3]=vsrc[0];

	// restore the bottom row of pixels + 2 pixels
	for ( unsigned int a=1;a<width/2+2;a++){
		output[a*4+0]=output[a*4-2]+ysrc[a*2+0];
		output[a*4+1]=output[a*4-3]+usrc[a];
		output[a*4+2]=output[a*4-0]+ysrc[a*2+1];
		output[a*4+3]=output[a*4-1]+vsrc[a];
	}

	if ( height==1)
		return;

	// 40
	// 38
	// 37

	const unsigned int stride = width*2;
	unsigned int a=width/2+2;
	__m128i x = _mm_setr_epi8(output[a*4-2],output[a*4-3],0,output[a*4-1],0,0,0,0,0,0,0,0,0,0,0,0);
	__m128i z = _mm_setr_epi8(output[a*4-3-stride],output[a*4-2-stride],output[a*4-1-stride],0,0,0,0,0,0,0,0,0,0,0,0,0);
	const __m128i mask = _mm_setr_epi8(0,0,0,0,-1,0,0,0,0,0,0,0,0,0,0,0);

	// restore all the remaining pixels using median prediction
	const __m128i mask2 = _mm_setr_epi8(0,0,-1,0,0,-1,0,-1,0,0,0,0,0,0,0,0);
	for ( ; a<(height*width)/2; a+=2){
		__m128i srcs = _mm_cvtsi32_si128( *(unsigned int *)&ysrc[a*2]);
		__m128i temp0 = _mm_insert_epi16(_mm_setzero_si128(),*(int*)&usrc[a],0);
		__m128i temp1 = _mm_insert_epi16(_mm_setzero_si128(),*(int*)&vsrc[a],0);
		srcs = _mm_unpacklo_epi8(srcs,_mm_unpacklo_epi8(temp0,temp1));

		__m128i y = _mm_loadl_epi64((__m128i *)&output[a*4-stride]);

		z = _mm_or_si128(z,_mm_slli_si128(y,3)); // z=uyvyuyvy
		z = _mm_or_si128(_mm_srli_epi16(z,8),_mm_slli_epi16(z,8));// z = yuyvyuyv
		z = _mm_sub_epi8(_mm_add_epi8(x,y),z);

		__m128i i = _mm_min_epu8(x,y);//min
		__m128i j = _mm_max_epu8(x,y);//max
		i = _mm_max_epu8(i,z);//max
		j = _mm_min_epu8(i,j);//min
		j = _mm_add_epi8(j,srcs); // yu-v----
		// mask and shift j (yuv)
		j = _mm_shufflelo_epi16(j,(0<<0)+(0<<2)+(0<<4)+(1<<6));
		j = _mm_and_si128(j,mask2);
		x = _mm_or_si128(x,j);
		z = _mm_add_epi8(z,j);

		i = _mm_min_epu8(x,y);//min
		j = _mm_max_epu8(x,y);//max
		i = _mm_max_epu8(i,z);//max
		j = _mm_min_epu8(i,j);//min
		j = _mm_add_epi8(j,srcs); // yuyv----

		// mask and shift j (y only)
		j = _mm_and_si128(j,_mm_setr_epi16(0,255,0,0,0,0,0,0));
		j = _mm_slli_si128(j,2);

		x = _mm_or_si128(x,j);
		z = _mm_add_epi8(z,j);

		i = _mm_min_epu8(x,y);//min
		j = _mm_max_epu8(x,y);//max
		i = _mm_max_epu8(i,z);//max
		j = _mm_min_epu8(i,j);//min
		j = _mm_add_epi8(j,srcs); // yuyvyu-v
		// mask and shift j (y only)
		j = _mm_and_si128(j,mask);
		j = _mm_slli_si128(j,2);
		x = _mm_or_si128(x,j);
		z = _mm_add_epi8(z,j);

		i = _mm_min_epu8(x,y);//min
		x = _mm_max_epu8(x,y);//max
		i = _mm_max_epu8(i,z);//max
		x = _mm_min_epu8(i,x);//min
		x = _mm_add_epi8(x,srcs);
		_mm_storel_epi64((__m128i*)&output[a*4], x);
		j = x;
		x = _mm_slli_si128(x,9);
		x = _mm_srli_si128(x,15);
		j = _mm_srli_epi16(j,1*8);
		j = _mm_srli_si128(j,3);
		x = _mm_or_si128(x,j);

		z = _mm_srli_si128(y,5);
	}
}

void Interleave_And_Restore_RGB24( unsigned char * __restrict output, unsigned char * __restrict rsrc, const unsigned char * __restrict gsrc, const unsigned char * __restrict bsrc, const unsigned int width, const unsigned int height){

	const unsigned int stride = align_round(width*3,4);

	output[0]=bsrc[0];
	output[1]=gsrc[0];
	output[2]=rsrc[0];

	// restore the bottom row
	for ( unsigned int a=1;a<width;a++){
		output[a*3]=output[a*3-3]+bsrc[a];
		output[a*3+1]=output[a*3-2]+gsrc[a];
		output[a*3+2]=output[a*3-1]+rsrc[a];
	}

	if ( !height )
		return;

	// 81
	// 70
	// 55
	__m128i x,z;
	z = _mm_setzero_si128();
	x = _mm_cvtsi32_si128( output[0] + (output[1]<<8) + (output[2]<<16));
	x = _mm_unpacklo_epi8(x,z);

	const __m128i mask = _mm_setr_epi8(0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,0,0,0);

	unsigned int w=0;
	unsigned int h=0;

	// if there is no need for padding, treat it as one long row
	const unsigned int vsteps = (width&3)?height:2;
	const unsigned int wsteps = (width&3)?(width&(~3)):sub_us(width*height-width,4);

	for ( h=1;h<vsteps;h++){
		w=0;
		for ( ;w<wsteps;w+=4){
			unsigned int a = stride*h+w*3;
			__m128i b = _mm_cvtsi32_si128( *(unsigned int *)&bsrc[width*h+w] );
			__m128i g = _mm_cvtsi32_si128( *(unsigned int *)&gsrc[width*h+w] );
			__m128i r = _mm_cvtsi32_si128( *(unsigned int *)&rsrc[width*h+w] );
			b = _mm_unpacklo_epi8(b,g);
			r = _mm_unpacklo_epi8(r,r);

			__m128i src1 = _mm_unpacklo_epi16(b,r);
			__m128i src2 = _mm_unpackhi_epi8(src1,_mm_setzero_si128());
			src1 = _mm_unpacklo_epi8(src1,_mm_setzero_si128());

			__m128i y = _mm_loadl_epi64((__m128i *)&output[a-stride]);
			__m128i ys = _mm_cvtsi32_si128(*(int*)&output[a-stride+8]);
			y = _mm_unpacklo_epi64(y,ys);
			ys = y;
			y = _mm_and_si128(y,mask);
			y = _mm_or_si128(_mm_srli_si128(y,1),_mm_slli_si128(y,1));
			y = _mm_add_epi8(y,ys);
			_mm_storel_epi64((__m128i *)&output[a-stride],y);
			*(int*)&output[a-stride+8] = _mm_cvtsi128_si32(_mm_srli_si128(y,8));
			y = _mm_unpacklo_epi8(ys,_mm_setzero_si128());
			ys = _mm_srli_si128(ys,6);
			ys = _mm_unpacklo_epi8(ys,_mm_setzero_si128());

			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			__m128i i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src1);

			__m128i temp1 = _mm_slli_si128(x,2);
			
			z = y;
			y = _mm_srli_si128(y,6);
			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);
			src1 = _mm_srli_si128(src1,8);

			/*******/

			i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src1);

			temp1 = _mm_unpacklo_epi64(temp1,x);
			temp1 = _mm_slli_si128(temp1,2);

			z = _mm_sub_epi16(_mm_add_epi16(x,ys),y);
			y = ys;
			

			/*******/

			i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src2);

			src2 = _mm_srli_si128(src2,8);
			
			__m128i temp2 = _mm_slli_si128(x,2);

			z = y;
			y = _mm_srli_si128(y,6);
			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);
			
			/*******/

			i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src2);

			temp2 = _mm_unpacklo_epi64(temp2,x);
			temp2 = _mm_srli_si128(temp2,2);

			temp1 = _mm_packus_epi16(temp1,temp2);
			temp1 = _mm_srli_si128(temp1,2);

			_mm_storel_epi64((__m128i *)&output[a], temp1);
			temp1 = _mm_srli_si128(temp1,8);
			*(int*)&output[a+8] = _mm_cvtsi128_si32(temp1);

			z = y;
		}
		if ( h < vsteps-1){
			// if the width is not mod 4, take care of the remaining pixels in the row
			for ( ;w<width;w++){
			
				unsigned int a = stride*h+w*3;

				__m128i src = _mm_cvtsi32_si128(bsrc[width*h+w]+(gsrc[width*h+w]<<8)+(rsrc[width*h+w]<<16));
				src = _mm_unpacklo_epi8(src,_mm_setzero_si128());
			
				// row has padding, no overrun risk
				__m128i y = _mm_cvtsi32_si128(*(int *)&output[a-stride]);
				y = _mm_unpacklo_epi8(y,_mm_setzero_si128());

				output[a+0-stride]+=output[a+1-stride];
				output[a+2-stride]+=output[a+1-stride];
				z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

				__m128i i = _mm_min_epi16(x,y);//min
				x = _mm_max_epi16(x,y);//max
				i = _mm_max_epi16(i,z);//max
				x = _mm_min_epi16(i,x);//min
				x = _mm_add_epi8(x,src);

				// row has padding, no overrun risk
				*(int*)&output[a] = _mm_cvtsi128_si32(_mm_packus_epi16(x,x));

				z = y;
			}
		}
	}
	h = height-1;
	w %= width;
	for ( ;w<width;w++){	
		unsigned int a = stride*h+w*3;

		__m128i src = _mm_cvtsi32_si128(bsrc[width*h+w]+(gsrc[width*h+w]<<8)+(rsrc[width*h+w]<<16));
		src = _mm_unpacklo_epi8(src,_mm_setzero_si128());

		// row has padding, no overrun risk
		__m128i y = _mm_cvtsi32_si128(*(int *)&output[a-stride]);
		y = _mm_unpacklo_epi8(y,_mm_setzero_si128());

		output[a+0-stride]+=output[a+1-stride];
		output[a+2-stride]+=output[a+1-stride];
		z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

		__m128i i = _mm_min_epi16(x,y);//min
		x = _mm_max_epi16(x,y);//max
		i = _mm_max_epi16(i,z);//max
		x = _mm_min_epi16(i,x);//min
		x = _mm_add_epi8(x,src);

		unsigned int temp = _mm_cvtsi128_si32(_mm_packus_epi16(x,x));
		output[a+0] = temp;
		output[a+1] = temp>>8;
		output[a+2] = temp>>16;

		z = y;
	}

	for ( unsigned int a=stride*(height-1);a<stride*height;a+=3){
	//for ( unsigned int a=0;a<stride*height;a+=3){
		output[a]+=output[a+1];
		output[a+2]+=output[a+1];
	}
}

void Interleave_And_Restore_RGB32( unsigned char * __restrict output, unsigned char * __restrict rsrc, const unsigned char * __restrict gsrc, const unsigned char * __restrict bsrc, const unsigned int width, const unsigned int height){

	const unsigned int stride = width*4;
	output[0]=bsrc[0];
	output[1]=gsrc[0];
	output[2]=rsrc[0];
	output[3]=255;
	for ( unsigned int a=1;a<width;a++){
		output[a*4+0]=bsrc[a]+output[a*4-4];
		output[a*4+1]=gsrc[a]+output[a*4-3];
		output[a*4+2]=rsrc[a]+output[a*4-2];
		output[a*4+3]=255;
	}

	if ( height==1)
		return;

	//unsigned __int64 t1,t2;
	//static HANDLE file = CreateFile("C:\\Users\\Lags\\Desktop\\lag_log.cvs",GENERIC_WRITE,0,0,CREATE_ALWAYS,0,0);
	//t1 = GetTime();

	
	__m128i x,z;
	z = _mm_setzero_si128();
	x = _mm_cvtsi32_si128( *(unsigned int *)&output[0]);
	x = _mm_unpacklo_epi8(x,z);

	const unsigned int end = ((width*(height-1))&(~3))+width;
	unsigned int a=width;

	if ( (stride&15)==0){
		
		// 85
		// 77
		// 65
		// 46

		for ( ;a<end;a+=4){
			__m128i b = _mm_cvtsi32_si128( *(unsigned int *)&bsrc[a] );
			__m128i g = _mm_cvtsi32_si128( *(unsigned int *)&gsrc[a] );
			__m128i r = _mm_cvtsi32_si128( *(unsigned int *)&rsrc[a] );
			b = _mm_unpacklo_epi8(b,g);
			r = _mm_unpacklo_epi8(r,_mm_setzero_si128());

			__m128i src1 = _mm_unpacklo_epi16(b,r);
			__m128i src2 = _mm_unpackhi_epi8(src1,_mm_setzero_si128());
			src1 = _mm_unpacklo_epi8(src1,_mm_setzero_si128());

			__m128i temp2 = _mm_load_si128((__m128i *)&output[a*4-stride]); // must be %16
			__m128i y = _mm_unpacklo_epi8(temp2,_mm_setzero_si128());
			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			__m128i i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src1);
			src1 = _mm_srli_si128(src1,8);

			z = y;
			y = _mm_srli_si128(y,8);
			__m128i temp1 = x;

			/*******/
			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src1);

			temp1 = _mm_unpacklo_epi64(temp1,x);

			z = y;

			/*******/
			i = temp2;
			y = _mm_unpackhi_epi8(temp2,_mm_setzero_si128());
			temp2 = _mm_srli_epi16(temp2,8);
			temp2 = _mm_shufflelo_epi16(temp2,(0<<0)+(0<<2)+(2<<4)+(2<<6));
			temp2 = _mm_shufflehi_epi16(temp2,(0<<0)+(0<<2)+(2<<4)+(2<<6));
			temp2 = _mm_add_epi8(temp2,i);
			_mm_store_si128((__m128i *)&output[a*4-stride],temp2); // must be %16

			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src2);
			src2 = _mm_srli_si128(src2,8);

			z = y;
			y = _mm_srli_si128(y,8);
			temp2 = x;

			/*******/
			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src2);

			temp2 = _mm_unpacklo_epi64(temp2,x);
			temp1 = _mm_packus_epi16(temp1,temp2);

			_mm_store_si128((__m128i *)&output[a*4],temp1);

			z = y;
		}
	} else { // width is not mod 4, change pixel store to unaligned move

		// 52
		for ( ;a<end;a+=4){
			__m128i b = _mm_cvtsi32_si128( *(unsigned int *)&bsrc[a] );
			__m128i g = _mm_cvtsi32_si128( *(unsigned int *)&gsrc[a] );
			__m128i r = _mm_cvtsi32_si128( *(unsigned int *)&rsrc[a] );
			b = _mm_unpacklo_epi8(b,g);
			r = _mm_unpacklo_epi8(r,_mm_setzero_si128());

			__m128i src1 = _mm_unpacklo_epi16(b,r);
			__m128i src2 = _mm_unpackhi_epi8(src1,_mm_setzero_si128());
			src1 = _mm_unpacklo_epi8(src1,_mm_setzero_si128());

			__m128i temp2 = _mm_load_si128((__m128i *)&output[a*4-stride]); // must be %16
			__m128i y = _mm_unpacklo_epi8(temp2,_mm_setzero_si128());
			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			__m128i i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src1);
			src1 = _mm_srli_si128(src1,8);

			z = y;
			y = _mm_srli_si128(y,8);
			__m128i temp1 = x;

			/*******/
			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src1);

			temp1 = _mm_unpacklo_epi64(temp1,x);

			z = y;

			/*******/
			i = temp2;
			y = _mm_unpackhi_epi8(temp2,_mm_setzero_si128());
			temp2 = _mm_srli_epi16(temp2,8);
			temp2 = _mm_shufflelo_epi16(temp2,(0<<0)+(0<<2)+(2<<4)+(2<<6));
			temp2 = _mm_shufflehi_epi16(temp2,(0<<0)+(0<<2)+(2<<4)+(2<<6));
			temp2 = _mm_add_epi8(temp2,i);
			_mm_store_si128((__m128i *)&output[a*4-stride],temp2); // must be %16

			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src2);
			src2 = _mm_srli_si128(src2,8);

			z = y;
			y = _mm_srli_si128(y,8);
			temp2 = x;

			/*******/
			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src2);

			temp2 = _mm_unpacklo_epi64(temp2,x);
			temp1 = _mm_packus_epi16(temp1,temp2);

			_mm_storeu_si128((__m128i *)&output[a*4],temp1); // only change from aligned version

			z = y;
		}
	}

	// finish off any remaining pixels (0-3 pixels)
	for ( ;a < width*height;a++ ){
		__m128i src = _mm_cvtsi32_si128(bsrc[a]+(gsrc[a]<<8)+(rsrc[a]<<16));
		src = _mm_unpacklo_epi8(src,_mm_setzero_si128());

		__m128i y = _mm_cvtsi32_si128(*(int *)&output[a*4-stride]);
		output[a*4-stride+0] += output[a*4-stride+1];
		output[a*4-stride+2] += output[a*4-stride+1];
		y = _mm_unpacklo_epi8(y,_mm_setzero_si128());
		z = _mm_subs_epu16(_mm_add_epi16(x,y),z);

		__m128i i = _mm_min_epi16(x,y);//min
		x = _mm_max_epi16(x,y);//max
		i = _mm_max_epi16(i,z);//max
		x = _mm_min_epi16(x,i);//min
		x = _mm_add_epi8(x,src);

		*(int *)&output[a*4] = _mm_cvtsi128_si32(_mm_packus_epi16(x,x));

		z = y;
	}

	// finish recorrilating top row
	for ( a=stride*(height-1);a<stride*height;a+=4){
		output[a]+=output[a+1];
		output[a+2]+=output[a+1];
	}

	//t2 = GetTime();
	//t2 -= t1;
	//char msg[128];
	//sprintf(msg,"%f\n",t2/100000.0);
	//unsigned long bytes;
	//WriteFile(file,msg,strlen(msg),&bytes,NULL);
}

void Interleave_And_Restore_RGBA( unsigned char * __restrict output, unsigned char * __restrict rsrc, const unsigned char * __restrict gsrc, const unsigned char * __restrict bsrc, const unsigned char * __restrict asrc, const unsigned int width, const unsigned int height){
	
	const unsigned int stride = width*4;
	output[0]=bsrc[0];
	output[1]=gsrc[0];
	output[2]=rsrc[0];
	output[3]=asrc[0];
	for ( unsigned int a=1;a<width;a++){
		output[a*4+0]=bsrc[a]+output[a*4-4];
		output[a*4+1]=gsrc[a]+output[a*4-3];
		output[a*4+2]=rsrc[a]+output[a*4-2];
		output[a*4+3]=asrc[a]+output[a*4-1];
	}

	if ( height==1)
		return;

	
	__m128i x,z;
	z = _mm_setzero_si128();
	x = _mm_cvtsi32_si128( *(unsigned int *)&output[0]);
	x = _mm_unpacklo_epi8(x,z);

	const unsigned int end = ((width*(height-1))&(~3))+width;
	unsigned int a=width;

	if ( (stride&15)==0){
		
		// 85
		// 77
		// 65
		// 46

		for ( ;a<end;a+=4){
			__m128i b = _mm_cvtsi32_si128( *(unsigned int *)&bsrc[a] );
			__m128i g = _mm_cvtsi32_si128( *(unsigned int *)&gsrc[a] );
			__m128i r = _mm_cvtsi32_si128( *(unsigned int *)&rsrc[a] );
			__m128i alpha = _mm_cvtsi32_si128( *(unsigned int *)&asrc[a]);
			b = _mm_unpacklo_epi8(b,g);
			r = _mm_unpacklo_epi8(r,alpha);

			__m128i src1 = _mm_unpacklo_epi16(b,r);
			__m128i src2 = _mm_unpackhi_epi8(src1,_mm_setzero_si128());
			src1 = _mm_unpacklo_epi8(src1,_mm_setzero_si128());

			__m128i temp2 = _mm_load_si128((__m128i *)&output[a*4-stride]); // must be %16
			__m128i y = _mm_unpacklo_epi8(temp2,_mm_setzero_si128());
			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			__m128i i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src1);
			src1 = _mm_srli_si128(src1,8);

			z = y;
			y = _mm_srli_si128(y,8);
			__m128i temp1 = x;

			/*******/
			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src1);

			temp1 = _mm_unpacklo_epi64(temp1,x);

			z = y;

			/*******/
			i = temp2;
			y = _mm_unpackhi_epi8(temp2,_mm_setzero_si128());
			temp2 = _mm_srli_epi16(temp2,8);
			temp2 = _mm_shufflelo_epi16(temp2,(0<<0)+(0<<2)+(2<<4)+(2<<6));
			temp2 = _mm_shufflehi_epi16(temp2,(0<<0)+(0<<2)+(2<<4)+(2<<6));
			temp2 = _mm_add_epi8(temp2,i);
			_mm_store_si128((__m128i *)&output[a*4-stride],temp2); // must be %16

			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src2);
			src2 = _mm_srli_si128(src2,8);

			z = y;
			y = _mm_srli_si128(y,8);
			temp2 = x;

			/*******/
			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src2);

			temp2 = _mm_unpacklo_epi64(temp2,x);
			temp1 = _mm_packus_epi16(temp1,temp2);

			_mm_store_si128((__m128i *)&output[a*4],temp1);

			z = y;
		}
	} else { // width is not mod 4, change pixel store to unaligned move

		// 52
		for ( ;a<end;a+=4){
			__m128i b = _mm_cvtsi32_si128( *(unsigned int *)&bsrc[a] );
			__m128i g = _mm_cvtsi32_si128( *(unsigned int *)&gsrc[a] );
			__m128i r = _mm_cvtsi32_si128( *(unsigned int *)&rsrc[a] );
			__m128i alpha = _mm_cvtsi32_si128( *(unsigned int *)&asrc[a]);
			b = _mm_unpacklo_epi8(b,g);
			r = _mm_unpacklo_epi8(r,alpha);

			__m128i src1 = _mm_unpacklo_epi16(b,r);
			__m128i src2 = _mm_unpackhi_epi8(src1,_mm_setzero_si128());
			src1 = _mm_unpacklo_epi8(src1,_mm_setzero_si128());

			__m128i temp2 = _mm_load_si128((__m128i *)&output[a*4-stride]); // must be %16
			__m128i y = _mm_unpacklo_epi8(temp2,_mm_setzero_si128());
			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			__m128i i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src1);
			src1 = _mm_srli_si128(src1,8);

			z = y;
			y = _mm_srli_si128(y,8);
			__m128i temp1 = x;

			/*******/
			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src1);

			temp1 = _mm_unpacklo_epi64(temp1,x);

			z = y;

			/*******/
			i = temp2;
			y = _mm_unpackhi_epi8(temp2,_mm_setzero_si128());
			temp2 = _mm_srli_epi16(temp2,8);
			temp2 = _mm_shufflelo_epi16(temp2,(0<<0)+(0<<2)+(2<<4)+(2<<6));
			temp2 = _mm_shufflehi_epi16(temp2,(0<<0)+(0<<2)+(2<<4)+(2<<6));
			temp2 = _mm_add_epi8(temp2,i);
			_mm_store_si128((__m128i *)&output[a*4-stride],temp2); // must be %16

			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src2);
			src2 = _mm_srli_si128(src2,8);

			z = y;
			y = _mm_srli_si128(y,8);
			temp2 = x;

			/*******/
			z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

			i = _mm_min_epi16(x,y);//min
			x = _mm_max_epi16(x,y);//max
			i = _mm_max_epi16(i,z);//max
			x = _mm_min_epi16(i,x);//min
			x = _mm_add_epi8(x,src2);

			temp2 = _mm_unpacklo_epi64(temp2,x);
			temp1 = _mm_packus_epi16(temp1,temp2);

			_mm_storeu_si128((__m128i *)&output[a*4],temp1); // only change for unaligned version

			z = y;
		}
	}

	// finish off any remaining pixels (0-3 pixels)
	for ( ;a < width*height;a++ ){
		__m128i src = _mm_cvtsi32_si128(bsrc[a]+(gsrc[a]<<8)+(rsrc[a]<<16)+(asrc[a]<<24));
		src = _mm_unpacklo_epi8(src,_mm_setzero_si128());

		__m128i y = _mm_cvtsi32_si128(*(int *)&output[a*4-stride]);
		output[a*4-stride+0] += output[a*4-stride+1];
		output[a*4-stride+2] += output[a*4-stride+1];
		y = _mm_unpacklo_epi8(y,_mm_setzero_si128());
		z = _mm_subs_epu16(_mm_add_epi16(x,y),z);

		__m128i i = _mm_min_epi16(x,y);//min
		x = _mm_max_epi16(x,y);//max
		i = _mm_max_epi16(i,z);//max
		x = _mm_min_epi16(x,i);//min
		x = _mm_add_epi8(x,src);

		*(int *)&output[a*4] = _mm_cvtsi128_si32(_mm_packus_epi16(x,x));

		z = y;
	}

	// finish recorrilating top row
	for ( unsigned int a=stride*(height-1);a<stride*height;a+=4){
		output[a]+=output[a+1];
		output[a+2]+=output[a+1];
	}
}

void Restore_YV12(unsigned char * __restrict ysrc, unsigned char * __restrict usrc, unsigned char * __restrict vsrc, const unsigned int width, const unsigned int height){
	unsigned int a;
	for ( a=1;a<width/2;a++){
		usrc[a]+=usrc[a-1];
		vsrc[a]+=vsrc[a-1];
	}
	for ( a=1;a<width;a++){
		ysrc[a]+=ysrc[a-1];
	}

	//unsigned __int64 t1,t2;
	//static HANDLE file = CreateFile("C:\\Documents and Settings\\Administrator\\Desktop\\lag_log.cvs",GENERIC_WRITE,0,0,CREATE_ALWAYS,0,0);
	//t1 = GetTime();

	// 72 178
	// 41
	// 35
	const __m128i mask = _mm_setr_epi32(0x00ff00ff,0x00ff00ff,0,0);

	__m128i x = _mm_setr_epi16(ysrc[width-1],usrc[width/2-1],vsrc[width/2-1],0,0,0,0,0);
	__m128i z = _mm_setr_epi16(ysrc[0],usrc[0],vsrc[0],0,0,0,0,0);

	for ( a=width; a<((width*height/4 + width/2)&(~3)); a+=4){

		__m128i y = _mm_cvtsi32_si128(*(int*)&ysrc[a-width]);
		__m128i y1 = _mm_cvtsi32_si128(*(int*)&usrc[a-width/2-width/2]);
		__m128i y2 = _mm_cvtsi32_si128(*(int*)&vsrc[a-width/2-width/2]);
		y = _mm_unpacklo_epi8(y,y1);
		y2 = _mm_unpacklo_epi8(y2,_mm_setzero_si128());
		y = _mm_unpacklo_epi16(y,y2);

		__m128i srcs =_mm_cvtsi32_si128(*(int*)&ysrc[a]);
		__m128i s1 = _mm_cvtsi32_si128(*(int*)&usrc[a-width/2]);
		__m128i s2 = _mm_cvtsi32_si128(*(int*)&vsrc[a-width/2]);

		srcs = _mm_unpacklo_epi8(srcs,s1);
		s2 = _mm_unpacklo_epi8(s2,_mm_setzero_si128());
		srcs = _mm_unpacklo_epi16(srcs,s2);

		__m128i temp = _mm_unpackhi_epi64(y,srcs); // store for later
		y = _mm_unpacklo_epi8(y,_mm_setzero_si128());
		srcs = _mm_unpacklo_epi8(srcs,_mm_setzero_si128());

		z = _mm_unpacklo_epi64(z,y);
		z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

		__m128i i = _mm_min_epi16(x,y);
		__m128i j = _mm_max_epi16(x,y);
		i = _mm_max_epi16(i,z);
		j = _mm_min_epi16(j,i);
		j = _mm_add_epi8(j,srcs);
		j = _mm_slli_si128(j,8);
		x = _mm_or_si128(x,j);
		z = _mm_add_epi16(z,j);

		i = _mm_min_epi16(x,y);
		x = _mm_max_epi16(x,y);
		i = _mm_max_epi16(i,z);
		x = _mm_min_epi16(x,i);
		x = _mm_add_epi8(x,srcs);

		z = _mm_srli_si128(y,8);
		srcs = _mm_unpackhi_epi8(temp,_mm_setzero_si128());
		y = _mm_unpacklo_epi8(temp,_mm_setzero_si128());
		z = _mm_unpacklo_epi64(z,y);

		temp = x;
		x = _mm_srli_si128(x,8);

		z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

		i = _mm_min_epi16(x,y);
		j = _mm_max_epi16(x,y);
		i = _mm_max_epi16(i,z);
		j = _mm_min_epi16(j,i);
		j = _mm_add_epi8(j,srcs);
		j = _mm_slli_si128(j,8);
		x = _mm_or_si128(x,j);
		z = _mm_add_epi16(z,j);

		temp = _mm_or_si128(temp,_mm_srli_si128(temp,7));

		i = _mm_min_epi16(x,y);
		x = _mm_max_epi16(x,y);
		i = _mm_max_epi16(i,z);
		x = _mm_min_epi16(x,i);
		x = _mm_add_epi8(x,srcs);
		i = x;
		x = _mm_srli_si128(x,7);
		i = _mm_or_si128(i,x);
		temp = _mm_unpacklo_epi16(temp,i);

		*(int*)&ysrc[a]			= _mm_cvtsi128_si32(temp);
		*(int*)&usrc[a-width/2] = _mm_cvtsi128_si32(_mm_srli_si128(temp,4));
		*(int*)&vsrc[a-width/2] = _mm_cvtsi128_si32(_mm_srli_si128(temp,8));

		x = _mm_srli_epi16(x,8);
		z = _mm_srli_si128(y,8);
	}

	for ( ;a<width*height/4 + width/2;a++){
		int i = ysrc[a-1];
		int j = ysrc[a-width];
		int k = i+j-ysrc[a-width-1];
		ysrc[a]+=median(i,j,k);

		i = usrc[a-width/2-1];
		j = usrc[a-width/2-width/2];
		k = i+j-usrc[a-width/2-width/2-1];
		usrc[a-width/2]+=median(i,j,k);
		
		i = vsrc[a-width/2-1];
		j = vsrc[a-width/2-width/2];
		k = i+j-vsrc[a-width/2-width/2-1];
		vsrc[a-width/2]+=median(i,j,k);
	}

	unsigned int align8 = (a+7)&(~7);
	for ( ;a<align8;a++){
		int x = ysrc[a-1];
		int y = ysrc[a-width];
		int z = x+y-ysrc[a-width-1];
		x = median(x,y,z);
		ysrc[a]+=x;
	}

	x = _mm_cvtsi32_si128(ysrc[a-1]);
	z = _mm_cvtsi32_si128(ysrc[a-width-1]);

	__m128i shift_mask = _mm_cvtsi32_si128(255);

	for ( ;a<((width*height)&(~7));a+=8){
		__m128i src = _mm_loadl_epi64((__m128i*)&ysrc[a]);
		__m128i y = _mm_loadl_epi64((__m128i*)&ysrc[a-width]);
		y = _mm_unpacklo_epi8(y,_mm_setzero_si128());
		src = _mm_unpacklo_epi8(src,_mm_setzero_si128());

		z = _mm_or_si128(z,_mm_slli_si128(y,2));

		z = _mm_sub_epi16(_mm_add_epi16(x,y),z);

		__m128i i = _mm_min_epi16(x,y);
		__m128i j = _mm_max_epi16(x,y);
		i = _mm_max_epi16(i,z);
		j = _mm_min_epi16(j,i);
		j = _mm_add_epi8(j,src); // 1 correct
		// mask and shift j
		j = _mm_and_si128(j,shift_mask);
		j = _mm_slli_si128(j,2);
		shift_mask = _mm_slli_si128(shift_mask,2);
		x = _mm_or_si128(x,j);
		z = _mm_add_epi16(z,j);

		i = _mm_min_epi16(x,y);
		j = _mm_max_epi16(x,y);
		i = _mm_max_epi16(i,z);
		j = _mm_min_epi16(j,i);
		j = _mm_add_epi8(j,src); // 2 correct
		// mask and shift j
		j = _mm_and_si128(j,shift_mask);
		j = _mm_slli_si128(j,2);
		shift_mask = _mm_slli_si128(shift_mask,2);
		x = _mm_or_si128(x,j);
		z = _mm_add_epi16(z,j);

		i = _mm_min_epi16(x,y);
		j = _mm_max_epi16(x,y);
		i = _mm_max_epi16(i,z);
		j = _mm_min_epi16(j,i);
		j = _mm_add_epi8(j,src); // 3 correct
		// mask and shift j
		j = _mm_and_si128(j,shift_mask);
		j = _mm_slli_si128(j,2);
		shift_mask = _mm_slli_si128(shift_mask,2);
		x = _mm_or_si128(x,j);
		z = _mm_add_epi16(z,j);

		i = _mm_min_epi16(x,y);
		j = _mm_max_epi16(x,y);
		i = _mm_max_epi16(i,z);
		j = _mm_min_epi16(j,i);
		j = _mm_add_epi8(j,src); // 4 correct
		j = _mm_and_si128(j,shift_mask);
		j = _mm_slli_si128(j,2);
		shift_mask = _mm_slli_si128(shift_mask,2);
		x = _mm_or_si128(x,j);
		z = _mm_add_epi16(z,j);

		i = _mm_min_epi16(x,y);
		j = _mm_max_epi16(x,y);
		i = _mm_max_epi16(i,z);
		j = _mm_min_epi16(j,i);
		j = _mm_add_epi8(j,src); // 5 correct
		j = _mm_and_si128(j,shift_mask);
		j = _mm_slli_si128(j,2);
		shift_mask = _mm_slli_si128(shift_mask,2);
		x = _mm_or_si128(x,j);
		z = _mm_add_epi16(z,j);

		i = _mm_min_epi16(x,y);
		j = _mm_max_epi16(x,y);
		i = _mm_max_epi16(i,z);
		j = _mm_min_epi16(j,i);
		j = _mm_add_epi8(j,src); // 6 correct
		j = _mm_and_si128(j,shift_mask);
		j = _mm_slli_si128(j,2);
		shift_mask = _mm_slli_si128(shift_mask,2);
		x = _mm_or_si128(x,j);
		z = _mm_add_epi16(z,j);

		i = _mm_min_epi16(x,y);
		j = _mm_max_epi16(x,y);
		i = _mm_max_epi16(i,z);
		j = _mm_min_epi16(j,i);
		j = _mm_add_epi8(j,src); // 7 correct
		j = _mm_and_si128(j,shift_mask);
		j = _mm_slli_si128(j,2);
		shift_mask = _mm_srli_si128(shift_mask,12);
		x = _mm_or_si128(x,j);
		z = _mm_add_epi16(z,j);

		i = _mm_min_epi16(x,y);
		x = _mm_max_epi16(x,y);
		i = _mm_max_epi16(i,z);
		x = _mm_min_epi16(x,i);
		x = _mm_add_epi8(x,src); // 8 correct

		_mm_storel_epi64((__m128i*)&ysrc[a], _mm_packus_epi16(x,x));

		x = _mm_srli_si128(x,14);
		z = _mm_srli_si128(y,14);
	}

	for ( ;a<width*height;a++){
		int x = ysrc[a-1];
		int y = ysrc[a-width];
		int z = x+y-ysrc[a-width-1];
		x = median(x,y,z);
		ysrc[a]+=x;
	}

	
	//t2 = GetTime();
	//t2 -= t1;
	//char msg[128];
	//sprintf(msg,"%f\n",t2/100000.0);
	//unsigned long bytes;
	//WriteFile(file,msg,strlen(msg),&bytes,NULL);
}
#endif