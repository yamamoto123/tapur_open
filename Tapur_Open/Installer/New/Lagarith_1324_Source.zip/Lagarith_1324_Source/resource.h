//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by config.rc
//
#define IDS_TIP_NULLFRAMES              1
#define IDS_TIP_SUGGEST                 2
#define IDS_TIP_MULTI                   3
#define IDS_TIP_BITDEPTH                4
#define IDS_TIP_INTERLACED              4
#define IDS_TIP_LOSSY_OPTION            5
#define IDS_TIP_NOUPSAMPLE				6
#define IDD_DIALOG1                     101
#define IDC_CURSOR1                     102
#define IDC_CURSOR2                     103
#define IDB_BITMAP1                     104
#define IDC_NULL                        1001
#define IDC_OK                          1007
#define IDC_CANCEL                      1008
#define IDC_RGBA                        1009
#define IDC_NULLFRAMES                  1010
#define IDC_SUGGEST                     1011
#define IDC_EMAIL                       1012
#define IDC_MULTI                       1014
#define IDC_BITDEPTH                    1015
#define IDC_INTERLACED                  1015
#define IDC_LOSSY_OPTIONS               1016
#define IDC_VERSION                     1017
#define IDC_NOUPSAMPLE                  1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
