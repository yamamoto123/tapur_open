#ifndef _RLE_CPP
#define _RLE_CPP

#include <stdlib.h>
#include <memory.h>
#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <math.h>

// Mantained for compatablity with ealier versions, this is used
// to remove RLE compression on frequency headers.

namespace rle {

int deRLE(const unsigned char * in, unsigned char * out, int length,int level){
	int a=0;
	int b=0;
	int prev = !in[0];
	if ( level == 1 ){
		for ( ; b < length; a+=2 ){
			int x;
			int run=in[a+1];
			if ( run < 0x80 ){
				run*=2;
			} else{ 
				run=-run;
				run*=2;
				run--;
				run&=0xff;
			}

			for ( x = 0; x<=run;x++)
				out[b+x]=in[a];
			b+=x;
		}
		return a;
	} else if ( level == 2 ){
		while ( b < length){
			if ( in[a]!= prev ) {
				out[b++]=in[a];
				prev = in[a];
				a++;
			} else {
				int run=in[a+1];
				if ( run < 0x80 ){
					run*=2;
				} else{ 
					run=-run;
					run*=2;
					run--;
					run&=0xff;
				}
				int x=0;
				for (; x <= run;x++)
					out[b+x]=prev;
				b+=x;
				a+=2;
			}
		}
		return a;
	} else if (level==3){
		while ( b < length){
			if ( in[a]!=prev ) {
				out[b++]=in[a];
				prev = in[a++];
			} else if ( in[a+1]!=prev ){
				out[b]=in[a];
				out[b+1]=in[a+1];
				prev = in[a+1];
				b+=2;
				a+=2;
			} else {

				int run=in[a+2];
				if ( run < 0x80 ){
					run*=2;
				} else{ 
					run=-run;
					run*=2;
					run--;
					run&=0xff;
				}
				int x=0;
				for (; x < run+2;x++)
					out[b+x]=prev;
				b+=x;
				a+=3;
			}
		}
		return a;
	}
	return 0;
}

}
#endif