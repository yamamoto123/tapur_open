
#pragma once

namespace rle {

int deRLE(const unsigned char * in, unsigned char * out, int length,int level);

};
