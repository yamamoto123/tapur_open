#include "lagarith.h"
#include "prediction.h"
#include <float.h>

DWORD WINAPI encode_worker_thread( LPVOID i ){

	threadinfo * info = (threadinfo *)i;
	const unsigned int width = info->width;
	const unsigned int height = info->height;
	//const unsigned int length = width*height;
	const unsigned char * src=NULL;
	unsigned char * dest=NULL;
	unsigned char * const buffer = (unsigned char *)info->buffer;
	assert(buffer!=NULL);
	const unsigned int format=info->format;

	_controlfp(_PC_53 | _RC_NEAR, _MCW_PC | _MCW_RC);

	WaitForSingleObject(info->StartEvent,INFINITE);
	while ( true ){

		unsigned int length = info->length;
		if ( length == 0xFFFFFFFF ){
			break;
		} else if ( length > 0 ){
			src = (const unsigned char *)info->source;
			dest = (unsigned char *)info->dest;

			unsigned char * dst = buffer + ((unsigned int)src&15);
			assert(dst!=NULL);

			if ( format == YUY2 ){
				Block_Predict_YUV16(src,dst,width,length,false);
			} else {
				Block_Predict(src,dst,width,length,(format!=YV12));
			}

			info->size=info->cObj.Compact(dst,dest,length);
			assert( *(__int64*)dest != 0 );
			info->length=0;
		} else {
			assert(false);
		}

		SignalObjectAndWait(info->DoneEvent,info->StartEvent,INFINITE,false);
		
	}
	info->cObj.FreeCompressBuffers();
	lag_aligned_free(info->buffer,"Thread Buffer");
	info->length=0;
	return 0;
}

DWORD WINAPI decode_worker_thread( LPVOID i ){
	threadinfo * info = (threadinfo *)i;
	unsigned char * src=NULL;
	unsigned char * dest=NULL;

	_controlfp(_PC_53 | _RC_NEAR, _MCW_PC | _MCW_RC);

	WaitForSingleObject(info->StartEvent,INFINITE);
	while ( true ){

		unsigned int length = info->length;

		if ( length == 0xFFFFFFFF ){
			break;
		} else if ( length > 0 ){
			src = (unsigned char *)info->source;
			dest = (unsigned char *)info->dest;

			info->cObj.Uncompact(src,dest,length);
			info->length=0;
		} else {
			assert(false);
		}
		SignalObjectAndWait(info->DoneEvent,info->StartEvent,INFINITE,false);
	}
	info->cObj.FreeCompressBuffers();
	info->length=0;
	return 0;
}

int CodecInst::InitThreads( int encode ){

	DWORD temp;
	info_a.length=0;
	info_b.length=0;
	info_c.length=0;

	info_a.StartEvent=CreateEvent(NULL,false,false,NULL);
	info_a.DoneEvent=CreateEvent(NULL,false,false,NULL);
	info_b.StartEvent=CreateEvent(NULL,false,false,NULL);
	info_b.DoneEvent=CreateEvent(NULL,false,false,NULL);
	info_c.StartEvent=CreateEvent(NULL,false,false,NULL);
	info_c.DoneEvent=CreateEvent(NULL,false,false,NULL);

	unsigned int use_format=format;
	if ( lossy_option ){
		if ( lossy_option==1 ){
			use_format=YUY2;
		} else {
			use_format=YV12;
		}
	}

	if ( use_format > YUY2 ){
		info_a.width=width;
		info_b.width=width;
	} else {
		info_a.width=width/2;
		info_b.width=width/2;
	}
	info_c.width=width;

	
	if ( use_format != YV12 ){
		info_a.height=height;
		info_b.height=height;
	} else {
		info_a.height=height/2;
		info_b.height=height/2;
	}
	info_c.height=height;

	info_a.format=use_format;
	info_b.format=use_format;
	info_c.format=use_format;

	info_a.thread=NULL;
	info_b.thread=NULL;
	info_c.thread=NULL;
	info_a.buffer=NULL;
	info_b.buffer=NULL;
	info_c.buffer=NULL;
#ifdef _DEBUG 
	info_a.name="Thread A";
	info_b.name="Thread B";
	info_c.name="Thread C";
#endif

	int buffer_size = align_round(info_a.width,16)*info_a.height+256;

	bool memerror = false;
	bool interror = false;

	if ( encode ) {
		if ( !info_a.cObj.InitCompressBuffers( buffer_size ) || !info_b.cObj.InitCompressBuffers( buffer_size )) {
			memerror = true;
		}
	}
	if ( !memerror ){
		if ( lossy_option==0 && format == RGB32 ){
			if ( encode ){
				if ( !info_c.cObj.InitCompressBuffers( buffer_size )) {
					memerror = true;
				}
			}
			if ( !memerror ){
				if ( encode ){
					info_c.thread=CreateThread(NULL,0, encode_worker_thread, &info_c,CREATE_SUSPENDED,&temp);
				} else {
					info_c.thread=CreateThread(NULL,0, decode_worker_thread, &info_c,CREATE_SUSPENDED,&temp);
				}
				if ( info_c.thread ){
					SetThreadPriority(info_c.thread,THREAD_PRIORITY_BELOW_NORMAL);
				} else {
					interror = true;
				}
			}
		}
		if ( !interror && !memerror ){
			if ( encode ){
				info_a.thread=CreateThread(NULL,0, encode_worker_thread, &info_a,CREATE_SUSPENDED,&temp);
				info_b.thread=CreateThread(NULL,0, encode_worker_thread, &info_b,CREATE_SUSPENDED,&temp);
			} else {
				info_a.thread=CreateThread(NULL,0, decode_worker_thread, &info_a,CREATE_SUSPENDED,&temp);
				info_b.thread=CreateThread(NULL,0, decode_worker_thread, &info_b,CREATE_SUSPENDED,&temp);
			}
			if ( !info_a.thread || !info_b.thread || (use_format==RGB32 && !info_c.thread )){
				interror = true;
			} else {
				SetThreadPriority(info_a.thread,THREAD_PRIORITY_BELOW_NORMAL);
				SetThreadPriority(info_b.thread,THREAD_PRIORITY_BELOW_NORMAL);
			}
		}
	}
	
	if ( !memerror && !interror && encode ){
		info_a.buffer = (unsigned char *)lag_aligned_malloc((void *)info_a.buffer,buffer_size,16,"Info_a.buffer");
		info_b.buffer = (unsigned char *)lag_aligned_malloc((void *)info_b.buffer,buffer_size,16,"Info_b.buffer");
		if ( format == RGB32 ){
			info_c.buffer = (unsigned char *)lag_aligned_malloc((void *)info_c.buffer,buffer_size,16,"Info_c.buffer");
			if ( info_c.buffer == NULL )
				memerror = true;
		}
		if (info_a.buffer == NULL || info_b.buffer == NULL ){
			memerror = true;
		}
	}

	if ( memerror || interror ){

		if ( encode ){
			lag_aligned_free(info_a.buffer,"Info_a.buffer");
			lag_aligned_free(info_b.buffer,"Info_b.buffer");
			info_a.cObj.FreeCompressBuffers();
			info_b.cObj.FreeCompressBuffers();
			info_c.cObj.FreeCompressBuffers();
			lag_aligned_free(info_c.buffer,"Info_c.buffer");
		}

		info_a.thread=NULL;
		info_b.thread=NULL;
		info_c.thread=NULL;
		if ( memerror ){
			return ICERR_MEMORY;
		} else {
			return ICERR_INTERNAL;
		}
	} else {
		ResumeThread(info_a.thread);
		ResumeThread(info_b.thread);
		if ( info_c.thread ){
			ResumeThread(info_c.thread);
		}
		return ICERR_OK;
	}
}

void CodecInst::EndThreads(){
	info_a.length=0xFFFFFFFF;
	info_b.length=0xFFFFFFFF;
	info_c.length=0xFFFFFFFF;
	if ( info_a.thread ){
		SetEvent(info_a.StartEvent);
	}
	if ( info_b.thread ){
		SetEvent(info_b.StartEvent);
	}
	if ( info_c.thread ){
		SetEvent(info_c.StartEvent);
		HANDLE threads[3];
		threads[0]=info_a.thread;
		threads[1]=info_b.thread;
		threads[2]=info_c.thread;
		WaitForMultipleObjectsEx(3,&threads[0],true,10000,true);
	} else {
		HANDLE threads[2];
		threads[0]=info_a.thread;
		threads[1]=info_b.thread;
		WaitForMultipleObjectsEx(2,&threads[0],true,10000,true);
	}

	if ( !CloseHandle(info_a.thread) ){
		/*LPVOID lpMsgBuf;
		FormatMessage( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | 
			FORMAT_MESSAGE_FROM_SYSTEM | 
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			GetLastError(),
			0, // Default language
			(LPTSTR) &lpMsgBuf,
			0,
			NULL 
		);
		MessageBox( NULL, (char *)lpMsgBuf, "Error", MB_OK | MB_ICONINFORMATION );
		LocalFree( lpMsgBuf );*/
		//MessageBox (HWND_DESKTOP, "CloseHandle failed for thread A", "Error", MB_OK | MB_ICONEXCLAMATION);
	}
	if ( !CloseHandle(info_b.thread) ){
	//	MessageBox (HWND_DESKTOP, "CloseHandle failed for thread B", "Error", MB_OK | MB_ICONEXCLAMATION);
	}
	if ( info_c.thread && format == RGB32 && !CloseHandle(info_c.thread) ){
		//MessageBox (HWND_DESKTOP,"CloseHandle failed for thread C", "Error", MB_OK | MB_ICONEXCLAMATION);
	}
	info_a.thread=NULL;
	info_b.thread=NULL;
	info_c.thread=NULL;
	info_a.length=0;
	info_b.length=0;
	info_c.length=0;
}

//MessageBox (HWND_DESKTOP, msg, "Error", MB_OK | MB_ICONEXCLAMATION);