
#pragma once

#define lag_ResumeThread(x) {\
	while( ResumeThread(x) != 1){\
		Sleep(1);\
	}\
}

#define wait_for_threads( num_threads) { \
	if ( num_threads == 2) { \
		HANDLE events[2];\
		events[0]=info_a.DoneEvent;\
		events[1]=info_b.DoneEvent;\
		WaitForMultipleObjects(2, &events[0], true, INFINITE);\
	} else if ( num_threads == 3 ){ \
		HANDLE events[3];\
		events[0]=info_a.DoneEvent;\
		events[1]=info_b.DoneEvent;\
		events[2]=info_c.DoneEvent;\
		WaitForMultipleObjects(3, &events[0], true, INFINITE);\
	} \
}
