unsigned __int64 GetTime(){
	unsigned __int64 tsc=0;
	__asm{
		lea		ebx,tsc
		rdtsc
		mov		[ebx],eax
		mov		[ebx+4],edx

	}
	return tsc;
}

		unsigned __int64 t1,t2,t3,t4;
		static HANDLE file = CreateFile("C:\\Documents and Settings\\greenwbr\\Desktop\\lag_log.cvs",GENERIC_WRITE,0,0,CREATE_ALWAYS,0,0);
		t1 = GetTime();

		t4 = GetTime();

		t4 -= t3;
		t3 -= t2;
		t2 -= t1;
		char msg[128];
		sprintf(msg,"%f\t%f\t%f\n",t4/100000.0,t3/100000.0,t2/100000.0);
		unsigned long bytes;
		WriteFile(file,msg,strlen(msg),&bytes,NULL);