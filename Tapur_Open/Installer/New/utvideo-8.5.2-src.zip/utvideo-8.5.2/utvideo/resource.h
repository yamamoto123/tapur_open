//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by utvideo.rc
//
#define IDD_DIALOG1                     101
#define IDD_CONFIG_DIALOG               101
#define IDD_GLOBAL_CONFIG_DIALOG        129
#define IDC_DIVIDE_COUNT_EDIT           1001
#define IDC_SAVE_CONFIG_CHECK           1001
#define IDC_CHECK1                      1002
#define IDC_ASSUME_INTERLACE_CHECK      1002
#define IDC_IGNORE_SET_CONFIG_CHECK     1002
#define IDC_INTRAFRAME_PREDICT_MEDIAN_RADIO 1003
#define IDC_INTRAFRAME_PREDICT_LEFT_RADIO 1004
#define IDC_CHECK2                      1005
#define IDC_DIVIDE_COUNT_IS_NUM_PROCESSORS 1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
